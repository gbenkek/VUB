/*
 * VUBlib.h
 *
 * Created: 26.6.2022. 14:26:45
 * Author : Goran
 */ 

#ifndef VUBlib_h
#define VUBlib_h
#include <Arduino.h>

//LED
#define redLED 8
#define yellowLED 9
#define greenLED 10
#define blueLED 11
//RGB
#define redRGB 9
#define greenRGB 10
#define blueRGB 11
//SERVO
#define servoPin 9
//LCD
#define rsPin A5
#define enPin A4
#define d4Pin 13
#define d5Pin 5
#define d6Pin 6
#define d7Pin 12
//Zujalica
#define buzzPin A3
//NTC
#define ntcPin A3
//Potenciometar
#define potPin A2
//LM35
#define lm35Pin A2
//Tipkala
#define button1 3
#define button2 2
#define button3 A1
#define button4 A0
//Rotancijski enkoder
#define pushButton A0
#define chA 3
#define chB 2
//Relej
#define relayPin 4
//HCSR04
#define trigPin 4
#define echoPin 7
//Numericki zaslon
#define siPin 13
#define sckPin A4
#define rckPin A5

//Custom Character
byte Smiley[8] = {
  B00000,
  B10001,
  B00000,
  B00000,
  B10001,
  B01110,
  B00000,
};

byte Bell[8] = {
B00100,
  B01110,
  B01110,
  B01110,
  B01110,
  B11111,
  B00000,
  B00100
};

byte Alien[8] = {
B11111,
B10101,
B11111,
B11111,
B01110,
B01010,
B11011,
B00000
};

byte Check[8] = {
B00000,
B00001,
B00011,
B10110,
B11100,
B01000,
B00000,
B00000
};

byte Sound[8] = {
B00001,
B00011,
B00101,
B01001,
B01001,
B01011,
B11011,
B11000
};

byte Skull[8] = {
B00000,
B01110,
B10101,
B11011,
B01110,
B01110,
B00000,
B00000
};

byte Lock[8] = {
B01110,
B10001,
B10001,
B11111,
B11011,
B11011,
B11111,
B00000
};

byte Speaker[8] = {
B00001,
B00011,
B01111,
B01111,
B01111,
B00011,
B00001,
B00000
};

void itsMario(){
	tone(buzzPin,660,100);
	delay(150);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,510,100);
	delay(100);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,770,100);
	delay(550);
	tone(buzzPin,380,100);
	delay(575);

	tone(buzzPin,510,100);
	delay(450);
	tone(buzzPin,380,100);
	delay(400);
	tone(buzzPin,320,100);
	delay(500);
	tone(buzzPin,440,100);
	delay(300);
	tone(buzzPin,480,80);
	delay(330);
	tone(buzzPin,450,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(300);
	tone(buzzPin,380,100);
	delay(200);
	tone(buzzPin,660,80);
	delay(200);
	tone(buzzPin,760,50);
	delay(150);
	tone(buzzPin,860,100);
	delay(300);
	tone(buzzPin,700,80);
	delay(150);
	tone(buzzPin,760,50);
	delay(350);
	tone(buzzPin,660,80);
	delay(300);
	tone(buzzPin,520,80);
	delay(150);
	tone(buzzPin,580,80);
	delay(150);
	tone(buzzPin,480,80);
	delay(500);

	tone(buzzPin,510,100);
	delay(450);
	tone(buzzPin,380,100);
	delay(400);
	tone(buzzPin,320,100);
	delay(500);
	tone(buzzPin,440,100);
	delay(300);
	tone(buzzPin,480,80);
	delay(330);
	tone(buzzPin,450,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(300);
	tone(buzzPin,380,100);
	delay(200);
	tone(buzzPin,660,80);
	delay(200);
	tone(buzzPin,760,50);
	delay(150);
	tone(buzzPin,860,100);
	delay(300);
	tone(buzzPin,700,80);
	delay(150);
	tone(buzzPin,760,50);
	delay(350);
	tone(buzzPin,660,80);
	delay(300);
	tone(buzzPin,520,80);
	delay(150);
	tone(buzzPin,580,80);
	delay(150);
	tone(buzzPin,480,80);
	delay(500);

	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,150);
	delay(300);
	tone(buzzPin,380,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(150);

	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,430,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(100);
	tone(buzzPin,570,100);
	delay(220);

	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,200);
	delay(300);

	tone(buzzPin,1020,80);
	delay(300);
	tone(buzzPin,1020,80);
	delay(150);
	tone(buzzPin,1020,80);
	delay(300);

	tone(buzzPin,380,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,150);
	delay(300);
	tone(buzzPin,380,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(150);

	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,430,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(100);
	tone(buzzPin,570,100);
	delay(420);

	tone(buzzPin,585,100);
	delay(450);

	tone(buzzPin,550,100);
	delay(420);

	tone(buzzPin,500,100);
	delay(360);

	tone(buzzPin,380,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,150);
	delay(300);
	tone(buzzPin,380,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(150);

	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,430,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(100);
	tone(buzzPin,570,100);
	delay(220);

	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,200);
	delay(300);

	tone(buzzPin,1020,80);
	delay(300);
	tone(buzzPin,1020,80);
	delay(150);
	tone(buzzPin,1020,80);
	delay(300);

	tone(buzzPin,380,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,760,100);
	delay(100);
	tone(buzzPin,720,100);
	delay(150);
	tone(buzzPin,680,100);
	delay(150);
	tone(buzzPin,620,150);
	delay(300);

	tone(buzzPin,650,150);
	delay(300);
	tone(buzzPin,380,100);
	delay(150);
	tone(buzzPin,430,100);
	delay(150);

	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,430,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(100);
	tone(buzzPin,570,100);
	delay(420);

	tone(buzzPin,585,100);
	delay(450);

	tone(buzzPin,550,100);
	delay(420);

	tone(buzzPin,500,100);
	delay(360);

	tone(buzzPin,380,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(300);
	tone(buzzPin,500,100);
	delay(150);
	tone(buzzPin,500,100);
	delay(300);

	tone(buzzPin,500,60);
	delay(150);
	tone(buzzPin,500,80);
	delay(300);
	tone(buzzPin,500,60);
	delay(350);
	tone(buzzPin,500,80);
	delay(150);
	tone(buzzPin,580,80);
	delay(350);
	tone(buzzPin,660,80);
	delay(150);
	tone(buzzPin,500,80);
	delay(300);
	tone(buzzPin,430,80);
	delay(150);
	tone(buzzPin,380,80);
	delay(600);

	tone(buzzPin,500,60);
	delay(150);
	tone(buzzPin,500,80);
	delay(300);
	tone(buzzPin,500,60);
	delay(350);
	tone(buzzPin,500,80);
	delay(150);
	tone(buzzPin,580,80);
	delay(150);
	tone(buzzPin,660,80);
	delay(550);

	tone(buzzPin,870,80);
	delay(325);
	tone(buzzPin,760,80);
	delay(600);

	tone(buzzPin,500,60);
	delay(150);
	tone(buzzPin,500,80);
	delay(300);
	tone(buzzPin,500,60);
	delay(350);
	tone(buzzPin,500,80);
	delay(150);
	tone(buzzPin,580,80);
	delay(350);
	tone(buzzPin,660,80);
	delay(150);
	tone(buzzPin,500,80);
	delay(300);
	tone(buzzPin,430,80);
	delay(150);
	tone(buzzPin,380,80);
	delay(600);

	tone(buzzPin,660,100);
	delay(150);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,510,100);
	delay(100);
	tone(buzzPin,660,100);
	delay(300);
	tone(buzzPin,770,100);
	delay(550);
	tone(buzzPin,380,100);
	delay(575);
}

void serialRGB( int rPin, int gPin, int bPin){
	String incomingString;
	String rgbString[3];
	
	 if (Serial.available() > 0) {

		 rgbString[0]="\0";
		 rgbString[1]="\0";
		 rgbString[2]="\0";
		 
		 incomingString = Serial.readString();

		 //Primjer poruke: =100;150;200;
		 if( incomingString[0] == '=') {
			 for(int i = 1, ii = 0; i < incomingString.length(); i++){
				 if(incomingString[i] == ';'){
					 ii++;
				 }
				 else{
					 rgbString[ii] += incomingString[i];
				 }
				 
			 }
		 }

		 analogWrite(rPin,rgbString[0].toInt());
		 analogWrite(gPin,rgbString[1].toInt());
		 analogWrite(bPin,rgbString[2].toInt());

	 }
	
}


#endif /* VUBlib_h */
